﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;

namespace Karate_fighting_spel
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        
        private Texture2D normal;
        private Texture2D jumping;
        private Texture2D crouch;
        private Texture2D fireballtexture;
        private Texture2D currenttexture;
        private SpriteFont font;

        private List<Vector2> fireballs;
        private int fireballtimer = 120;
        private Random rnd;

        private Vector2 position;
        private Vector2 speed;
        private bool isjumping;
        private bool isCrouchiing;
        private bool hit;
        private bool isplaying;
        private double score;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            position = new Vector2(300, 200);
            fireballs = new List<Vector2>();
            rnd = new Random();

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            normal = Content.Load<Texture2D>("normal");
            jumping = Content.Load<Texture2D>("jump");
            crouch = Content.Load<Texture2D>("crouch");
            fireballtexture = Content.Load<Texture2D>("fireball");
            font = Content.Load<SpriteFont>("font");

            // TODO: use this.Content to load your game content here
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            
            
            var state = Keyboard.GetState();

            if(state.IsKeyDown(Keys.Enter) && !isplaying)
            {
                Reset();
                isplaying = true;
            }

            if (!isplaying)
                return;

            score += gameTime.ElapsedGameTime.TotalSeconds;

            // TODO: Add your update logic here
            position += speed;
            if (position.Y > 200)
            {
                position = new Vector2(position.X, 200);
                speed = Vector2.Zero;
                isjumping = false;
            }

            speed += new Vector2(0, 0.5f);


            
            if (state.IsKeyDown(Keys.W) &&  !isjumping)
            {
                speed = new Vector2(0, -10.0f);
                isjumping = true;
            }
            if(state.IsKeyDown(Keys.S) && !isjumping)
            {
                isCrouchiing = true;
            }
            else
            {
                isCrouchiing = false;
            }


            fireballtimer--;
            if(fireballtimer <= 0)
            {
                fireballtimer = 120;
                if (rnd.Next(2) == 0)
                {
                    fireballs.Add(new Vector2(900, 230));
                }
                else
                {
                    fireballs.Add(new Vector2(900, 200));
                }
            }

            for(int i=0; i < fireballs.Count; i++)
            {

                fireballs[i] = fireballs[i] + new Vector2(-2, 0);
            }


            if (isjumping)
            {
                currenttexture = jumping; 
            }
            else if (isCrouchiing)
            {
                currenttexture = crouch;
            }
            else
            {
                currenttexture = normal;
            }

            Rectangle playerBox = new Rectangle((int)position.X, (int)position.Y, currenttexture.Width, currenttexture.Height);
            hit = false;


            foreach (var fireball in fireballs)
            {
                Rectangle fireballbox = new Rectangle((int)fireball.X, (int)fireball.Y, fireballtexture.Width, fireballtexture.Height);

                
                var kollision = Intersection(playerBox, fireballbox);

                if (kollision.Width > 0 && kollision.Height > 0)
                {
                    Rectangle r1 = Normalize(playerBox, kollision);
                    Rectangle r2 = Normalize(fireballbox, kollision);
                    hit = TestCollision(currenttexture, r1, fireballtexture, r2);
                    if (hit)
                    {
                        isplaying = false;
                    }
                }

            }
            



            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            _spriteBatch.Begin();

            if (isplaying)
            {




                _spriteBatch.DrawString(font, ((int) score).ToString(), new Vector2(10, 20), Color.White);

                if (hit)
                {
                    _spriteBatch.DrawString(font, "HIT!", new Vector2(10, 40), Color.White);
                }


                _spriteBatch.Draw(currenttexture, position, Color.White);


                foreach (var fireball in fireballs)
                {
                    _spriteBatch.Draw(fireballtexture, fireball, Color.White);
                }

            }

            else
            { 
                _spriteBatch.DrawString(font, "Press Enter to Start!", new Vector2(350, 200), Color.White);
            }

            _spriteBatch.End();


            // TODO: Add your drawing code here
            
            base.Draw(gameTime);
        }

        private void Reset()
        {
            fireballs.Clear();
            fireballtimer = 120;
            score = 0;
        }



        public static bool TestCollision(Texture2D t1, Rectangle r1, Texture2D t2, Rectangle r2)
        {
            //Beräkna hur många pixlar som finns i området som ska undersökas
            int pixelCount = r1.Width * r1.Height;
            uint[] texture1Pixels = new uint[pixelCount];
            uint[] texture2Pixels = new uint[pixelCount];

            //Kopiera ut pixlarna från båda områdena
            t1.GetData(0, r1, texture1Pixels, 0, pixelCount);
            t2.GetData(0, r2, texture2Pixels, 0, pixelCount);

            //Jämför om vi har några pixlar som överlappar varandra i områdena
            for (int i = 0; i < pixelCount; ++i)
            {
                if (((texture1Pixels[i] & 0xff000000) > 0) && ((texture2Pixels[i] & 0xff000000) > 0))
                {
                    return true;
                }
            }
            return false;
        }


        public static Rectangle Normalize(Rectangle reference, Rectangle overlap)
        {
            //Räkna ut en rektangel som kan användas relativt till referensrektangeln
            return new Rectangle(
              overlap.X - reference.X,
              overlap.Y - reference.Y,
              overlap.Width,
              overlap.Height);
        }


        public static Rectangle Intersection(Rectangle r1, Rectangle r2)
        {
            int x1 = Math.Max(r1.Left, r2.Left);
            int y1 = Math.Max(r1.Top, r2.Top);
            int x2 = Math.Min(r1.Right, r2.Right);
            int y2 = Math.Min(r1.Bottom, r2.Bottom);

            if ((x2 >= x1) && (y2 >= y1))
            {
                return new Rectangle(x1, y1, x2 - x1, y2 - y1);
            }
            return Rectangle.Empty;
        }

    }
}
